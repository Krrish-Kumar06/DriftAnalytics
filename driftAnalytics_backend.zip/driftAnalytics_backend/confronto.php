<?php
require "config.php";
$id = controlla_login();

$s1 = intval($_GET["s1"] ?? 0);
$s2 = intval($_GET["s2"] ?? 0);

if (!$s1 || !$s2) {
    json_out(["errore" => "Fornire s1 e s2 come ID delle due sessioni"]);
}

function leggi_sessione($conn, $sid, $uid) {
    $sessione = query_riga($conn, "
        SELECT s.id, s.data, p.nome AS pista,
               ROUND(AVG(dt.velocita), 1)            AS vel_media,
               ROUND(AVG(ABS(dt.angolo_derapata)), 1) AS angolo_medio,
               a.punteggio_generato                  AS score
        FROM Sessione s
        JOIN Pista p ON p.id = s.idPista
        LEFT JOIN Dati_Telemetrici dt ON dt.idSessione = s.id
        LEFT JOIN Analisi a           ON a.idSessione  = s.id
        WHERE s.id = ? AND s.idUtente = ?
        GROUP BY s.id
    ", [$sid, $uid]);

    if (!$sessione) return null;

    $rows  = query_lista($conn,
        "SELECT velocita FROM Dati_Telemetrici WHERE idSessione = ? ORDER BY timestamp ASC",
        [$sid]
    );
    $serie = [];
    foreach ($rows as $i => $row) {
        if ($i % 5 === 0) {
            $serie[] = floatval($row["velocita"]);
        }
    }
    $sessione["serie"] = $serie;
    return $sessione;
}

$a = leggi_sessione($conn, $s1, $id);
$b = leggi_sessione($conn, $s2, $id);

if (!$a || !$b) {
    json_out(["errore" => "Una o entrambe le sessioni non trovate"]);
}

json_out([
    "s1"          => $a,
    "s2"          => $b,
    "diff_vel"    => round($a["vel_media"]    - $b["vel_media"],    1),
    "diff_angolo" => round($a["angolo_medio"] - $b["angolo_medio"], 1),
    "diff_score"  => round(($a["score"] ?? 0) - ($b["score"] ?? 0), 1),
]);
?>
