<?php
require "config.php";

$action = $_GET["action"] ?? "";

if ($action === "check") {
    if (!empty($_SESSION["utente_id"])) {
        json_out(["loggato" => true, "nome" => $_SESSION["utente_nome"] . " " . $_SESSION["utente_cognome"]]);
    } else {
        json_out(["loggato" => false]);
    }
}

if ($action === "logout") {
    session_destroy();
    json_out(["ok" => true]);
}

if ($action === "citta") {
    $lista = query_lista($conn, "SELECT cap, nome, provincia FROM Citta ORDER BY nome");
    json_out($lista);
}

if ($action === "team") {
    $lista = query_lista($conn, "SELECT id, nome FROM Team ORDER BY nome");
    json_out($lista);
}

if ($action === "piste") {
    $lista = query_lista($conn, "
        SELECT p.id, p.nome, c.nome AS citta
        FROM Pista p
        JOIN Citta c ON c.cap = p.capCitta
        ORDER BY p.nome
    ");
    json_out($lista);
}

if ($action === "veicoli") {
    $id    = controlla_login();
    $lista = query_lista($conn, "
        SELECT v.id, v.marca, v.modello, v.anno
        FROM Possedere p
        JOIN Veicolo v ON v.id = p.idVeicolo
        WHERE p.idUtente = ?
    ", [$id]);
    json_out($lista);
}

json_out(["errore" => "Azione non valida"]);
?>
