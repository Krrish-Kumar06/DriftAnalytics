<?php
require "config.php";

$dati     = json_decode(file_get_contents("php://input"), true);
$email    = trim($dati["email"]    ?? "");
$password = trim($dati["password"] ?? "");

if (!$email || !$password) {
    json_out(["errore" => "Inserisci email e password"]);
}

$utente = query_riga($conn, "SELECT * FROM Utente WHERE email = ?", [$email]);

if (!$utente || !password_verify($password, $utente["password"])) {
    json_out(["errore" => "Email o password sbagliati"]);
}

$_SESSION["utente_id"]      = $utente["id"];
$_SESSION["utente_nome"]    = $utente["nome"];
$_SESSION["utente_cognome"] = $utente["cognome"];
$_SESSION["utente_email"]   = $utente["email"];

json_out(["ok" => true, "nome" => $utente["nome"] . " " . $utente["cognome"]]);
?>
