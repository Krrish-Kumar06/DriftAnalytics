<?php
require "config.php";
$id = controlla_login();

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    $cerca = trim($_GET["cerca"] ?? "");

    if ($cerca) {
        $lista = query_lista($conn, "
            SELECT s.id, s.data, s.durata,
                   p.nome AS pista,
                   ROUND(AVG(dt.velocita), 1)            AS vel_media,
                   ROUND(MAX(dt.velocita), 1)             AS vel_max,
                   ROUND(AVG(ABS(dt.angolo_derapata)), 1) AS angolo_medio,
                   a.punteggio_generato                  AS score
            FROM Sessione s
            JOIN Pista p ON p.id = s.idPista
            LEFT JOIN Dati_Telemetrici dt ON dt.idSessione = s.id
            LEFT JOIN Analisi a           ON a.idSessione  = s.id
            WHERE s.idUtente = ? AND p.nome LIKE ?
            GROUP BY s.id
            ORDER BY s.data DESC
        ", [$id, "%$cerca%"]);
    } else {
        $lista = query_lista($conn, "
            SELECT s.id, s.data, s.durata,
                   p.nome AS pista,
                   ROUND(AVG(dt.velocita), 1)            AS vel_media,
                   ROUND(MAX(dt.velocita), 1)             AS vel_max,
                   ROUND(AVG(ABS(dt.angolo_derapata)), 1) AS angolo_medio,
                   a.punteggio_generato                  AS score
            FROM Sessione s
            JOIN Pista p ON p.id = s.idPista
            LEFT JOIN Dati_Telemetrici dt ON dt.idSessione = s.id
            LEFT JOIN Analisi a           ON a.idSessione  = s.id
            WHERE s.idUtente = ?
            GROUP BY s.id
            ORDER BY s.data DESC
        ", [$id]);
    }

    json_out($lista);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $dati    = json_decode(file_get_contents("php://input"), true);
    $data    = trim($dati["data"]       ?? "");
    $durata  = intval($dati["durata"]   ?? 0);
    $idPista = intval($dati["idPista"]  ?? 0);
    $idVeic  = intval($dati["idVeicolo"] ?? 0);

    if (!$data || !$durata || !$idPista || !$idVeic) {
        json_out(["errore" => "Compila tutti i campi"]);
    }

    query_esegui($conn,
        "INSERT INTO Sessione (data, durata, idUtente, idPista, idVeicolo) VALUES (?, ?, ?, ?, ?)",
        [$data, $durata, $id, $idPista, $idVeic]
    );

    json_out(["ok" => true, "id" => $conn->lastInsertId()]);
}

json_out(["errore" => "Metodo non valido"]);
?>
