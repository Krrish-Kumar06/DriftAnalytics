<?php
require "config.php";
$id  = controlla_login();
$sid = intval($_GET["id"] ?? 0);

if (!$sid) {
    json_out(["errore" => "ID sessione mancante"]);
}

$sessione = query_riga($conn, "
    SELECT s.id, s.data, s.durata,
           p.nome AS pista,
           u.nome AS pilota, u.cognome AS pilota_cognome
    FROM Sessione s
    JOIN Pista p  ON p.id = s.idPista
    JOIN Utente u ON u.id = s.idUtente
    WHERE s.id = ? AND s.idUtente = ?
", [$sid, $id]);

if (!$sessione) {
    json_out(["errore" => "Sessione non trovata"]);
}

$telemetria = query_lista($conn, "
    SELECT velocita, angolo_derapata, accelerazione_laterale,
           accelerazione_longitudinale, yaw_rate,
           latitudine, longitudine, timestamp
    FROM Dati_Telemetrici
    WHERE idSessione = ?
    ORDER BY timestamp ASC
", [$sid]);

json_out(["sessione" => $sessione, "telemetria" => $telemetria]);
?>
