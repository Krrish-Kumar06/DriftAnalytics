<?php
require "config.php";
$id  = controlla_login();
$sid = intval($_GET["id"] ?? 0);

if (!$sid) {
    json_out(["errore" => "ID sessione mancante"]);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $dati     = json_decode(file_get_contents("php://input"), true);
    $commenti = trim($dati["commenti"] ?? "");
    $score    = floatval($dati["score"] ?? 0);

    $esiste = query_riga($conn, "SELECT id FROM Analisi WHERE idSessione = ?", [$sid]);

    if ($esiste) {
        query_esegui($conn,
            "UPDATE Analisi SET commenti = ?, punteggio_generato = ? WHERE idSessione = ?",
            [$commenti, $score, $sid]
        );
    } else {
        query_esegui($conn,
            "INSERT INTO Analisi (punteggio_generato, commenti, idSessione) VALUES (?, ?, ?)",
            [$score, $commenti, $sid]
        );
    }

    json_out(["ok" => true]);
}

$report = query_riga($conn, "
    SELECT s.id, s.data, s.durata,
           p.nome  AS pista,
           v.marca, v.modello,
           u.nome  AS pilota, u.cognome AS pilota_cognome,
           ROUND(AVG(dt.velocita), 1)            AS vel_media,
           ROUND(MAX(dt.velocita), 1)             AS vel_max,
           ROUND(AVG(ABS(dt.angolo_derapata)), 1) AS angolo_medio,
           a.punteggio_generato                  AS score,
           a.commenti
    FROM Sessione s
    JOIN Pista p    ON p.id = s.idPista
    JOIN Veicolo v  ON v.id = s.idVeicolo
    JOIN Utente u   ON u.id = s.idUtente
    LEFT JOIN Dati_Telemetrici dt ON dt.idSessione = s.id
    LEFT JOIN Analisi a           ON a.idSessione  = s.id
    WHERE s.id = ? AND s.idUtente = ?
    GROUP BY s.id
", [$sid, $id]);

if (!$report) {
    json_out(["errore" => "Sessione non trovata"]);
}

json_out($report);
?>
