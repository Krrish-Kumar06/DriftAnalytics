<?php
require "config.php";
$id = controlla_login();

$sessione = query_riga($conn, "
    SELECT s.id, s.data, s.durata,
           p.nome AS pista,
           ROUND(AVG(dt.velocita), 1)            AS vel_media,
           ROUND(MAX(dt.velocita), 1)             AS vel_max,
           ROUND(AVG(ABS(dt.angolo_derapata)), 1) AS angolo_medio,
           a.punteggio_generato                  AS score
    FROM Sessione s
    JOIN Pista p ON p.id = s.idPista
    LEFT JOIN Dati_Telemetrici dt ON dt.idSessione = s.id
    LEFT JOIN Analisi a           ON a.idSessione  = s.id
    WHERE s.idUtente = ?
    GROUP BY s.id
    ORDER BY s.data DESC
    LIMIT 1
", [$id]);

// Serie velocità per il grafico
$velocita = [];
if ($sessione) {
    $rows = query_lista($conn,
        "SELECT velocita FROM Dati_Telemetrici WHERE idSessione = ? ORDER BY timestamp ASC",
        [$sessione["id"]]
    );
    foreach ($rows as $i => $row) {
        if ($i % 5 === 0) {
            $velocita[] = floatval($row["velocita"]);
        }
    }
}

json_out(["sessione" => $sessione, "velocita" => $velocita]);
?>
