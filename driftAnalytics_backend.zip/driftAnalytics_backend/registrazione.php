<?php
require "config.php";

$dati     = json_decode(file_get_contents("php://input"), true);
$nome     = trim($dati["nome"]     ?? "");
$cognome  = trim($dati["cognome"]  ?? "");
$email    = trim($dati["email"]    ?? "");
$password = trim($dati["password"] ?? "");
$ruolo    = trim($dati["ruolo"]    ?? "pilota");
$capCitta = intval($dati["capCitta"] ?? 0);
$idTeam   = !empty($dati["idTeam"]) ? intval($dati["idTeam"]) : null;

if (!$nome || !$cognome || !$email || !$password) {
    json_out(["errore" => "Compila tutti i campi"]);
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    json_out(["errore" => "Email non valida"]);
}
if (strlen($password) < 6) {
    json_out(["errore" => "Password troppo corta (minimo 6 caratteri)"]);
}
if (!$capCitta) {
    json_out(["errore" => "Seleziona una città"]);
}

$esiste = query_riga($conn, "SELECT id FROM Utente WHERE email = ?", [$email]);
if ($esiste) {
    json_out(["errore" => "Email già registrata"]);
}

$hash = password_hash($password, PASSWORD_DEFAULT);

query_esegui($conn,
    "INSERT INTO Utente (nome, cognome, email, password, ruolo, capCitta, idTeam) VALUES (?, ?, ?, ?, ?, ?, ?)",
    [$nome, $cognome, $email, $hash, $ruolo, $capCitta, $idTeam]
);
$nuovo_id = $conn->lastInsertId();

$_SESSION["utente_id"]      = $nuovo_id;
$_SESSION["utente_nome"]    = $nome;
$_SESSION["utente_cognome"] = $cognome;
$_SESSION["utente_email"]   = $email;

json_out(["ok" => true, "nome" => "$nome $cognome"]);
?>
