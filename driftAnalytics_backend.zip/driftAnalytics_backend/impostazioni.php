<?php
require "config.php";
$id = controlla_login();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $dati    = json_decode(file_get_contents("php://input"), true);
    $nome    = trim($dati["nome"]    ?? "");
    $cognome = trim($dati["cognome"] ?? "");
    $email   = trim($dati["email"]   ?? "");

    if (!$nome || !$cognome || !$email) {
        json_out(["errore" => "Nome, cognome e email sono obbligatori"]);
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        json_out(["errore" => "Email non valida"]);
    }

    $esiste = query_riga($conn, "SELECT id FROM Utente WHERE email = ? AND id != ?", [$email, $id]);
    if ($esiste) {
        json_out(["errore" => "Email già usata da un altro account"]);
    }

    if (!empty($dati["nuova_password"])) {
        if (strlen($dati["nuova_password"]) < 6) {
            json_out(["errore" => "La password deve avere almeno 6 caratteri"]);
        }
        $hash = password_hash($dati["nuova_password"], PASSWORD_DEFAULT);
        query_esegui($conn,
            "UPDATE Utente SET nome = ?, cognome = ?, email = ?, password = ? WHERE id = ?",
            [$nome, $cognome, $email, $hash, $id]
        );
    } else {
        query_esegui($conn,
            "UPDATE Utente SET nome = ?, cognome = ?, email = ? WHERE id = ?",
            [$nome, $cognome, $email, $id]
        );
    }

    $_SESSION["utente_nome"]    = $nome;
    $_SESSION["utente_cognome"] = $cognome;
    json_out(["ok" => true]);
}

$utente = query_riga($conn, "
    SELECT u.id, u.nome, u.cognome, u.email, u.ruolo,
           c.nome AS citta,
           t.nome AS team
    FROM Utente u
    LEFT JOIN Citta c ON c.cap = u.capCitta
    LEFT JOIN Team t  ON t.id  = u.idTeam
    WHERE u.id = ?
", [$id]);

$veicolo = query_riga($conn, "
    SELECT v.marca, v.modello, v.anno, v.potenza
    FROM Possedere p
    JOIN Veicolo v ON v.id = p.idVeicolo
    WHERE p.idUtente = ?
    LIMIT 1
", [$id]);

$utente["auto"] = $veicolo ? $veicolo["marca"] . " " . $veicolo["modello"] : "";

json_out($utente);
?>
