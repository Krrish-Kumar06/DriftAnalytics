<?php
session_start();

$DB_HOST = "localhost";
$DB_NAME = "my_drift";
$DB_USER = "drift";
$DB_PASS = "";

try {
    $conn = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8", $DB_USER, $DB_PASS);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    json_out(["errore" => "Connessione al database fallita"]);
}

// Manda JSON al frontend
function json_out($dati) {
    header("Content-Type: application/json");
    echo json_encode($dati);
    exit;
}

// Esegue una query con parametri e restituisce tutte le righe
function query_lista($conn, $sql, $parametri = []) {
    $stmt = $conn->prepare($sql);
    $stmt->execute($parametri);
    return $stmt->fetchAll();
}

// Esegue una query con parametri e restituisce una sola riga
function query_riga($conn, $sql, $parametri = []) {
    $stmt = $conn->prepare($sql);
    $stmt->execute($parametri);
    return $stmt->fetch();
}

// Esegue una query senza risultato (INSERT, UPDATE, DELETE)
function query_esegui($conn, $sql, $parametri = []) {
    $stmt = $conn->prepare($sql);
    $stmt->execute($parametri);
}

// Controlla se l'utente è loggato, altrimenti blocca
function controlla_login() {
    if (empty($_SESSION["utente_id"])) {
        json_out(["errore" => "Non sei loggato"]);
    }
    return $_SESSION["utente_id"];
}
?>
